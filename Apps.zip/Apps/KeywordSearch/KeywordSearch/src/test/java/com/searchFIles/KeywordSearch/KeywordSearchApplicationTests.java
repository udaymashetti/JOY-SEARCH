package com.searchFIles.KeywordSearch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KeywordSearchApplicationTests {

	@Test
	void contextLoads() {
	}

}
