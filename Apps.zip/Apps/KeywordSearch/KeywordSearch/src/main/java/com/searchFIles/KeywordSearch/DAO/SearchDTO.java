package com.searchFIles.KeywordSearch.DAO;


public class SearchDTO {

	public SearchDTO() {
		// TODO Auto-generated constructor stub
	}
	
	private String keyWord;

	public String getKeyWord() {
		return keyWord;
	}

	public void setKeyWord(String keyWord) {
		this.keyWord = keyWord;
	}

}
