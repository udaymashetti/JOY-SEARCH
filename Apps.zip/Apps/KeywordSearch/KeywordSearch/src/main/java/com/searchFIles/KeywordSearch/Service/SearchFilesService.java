package com.searchFIles.KeywordSearch.Service;


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.util.FileCopyUtils;

@Service
public class SearchFilesService {

	public SearchFilesService() {
		// TODO Auto-generated constructor stub
	}
	
	public List<List<String>> getFIleNamesList(File[] listFiles,String searchString,String path) {
		ArrayList<List<String>> returnList = new ArrayList<>();
		
		
		for (File s :listFiles) {
        	if(s.isFile()) {
        		 //System.out.println("==========================");
        		File resource = new File(path+"/"+s.getName());
        		
        		try {
        			InputStream inputStream = new FileInputStream(resource);      			
                    byte[] bdata = FileCopyUtils.copyToByteArray(inputStream);
                    String data = new String(bdata, StandardCharsets.UTF_8);
                    if(data.contains(searchString)) {
                    	ArrayList<String> subList = new ArrayList<>();
                    	subList.add(s.getName());
                    	subList.add(s.getAbsolutePath());
                    	returnList.add(subList);
                    }
                
                } catch (IOException e) {
                   e.printStackTrace();
                }
        	}
        	else {
        		returnList.addAll(getFIleNamesList(s.listFiles(),searchString,s.getAbsolutePath()));
        	}
        	
        }
		return returnList;
	}

}
