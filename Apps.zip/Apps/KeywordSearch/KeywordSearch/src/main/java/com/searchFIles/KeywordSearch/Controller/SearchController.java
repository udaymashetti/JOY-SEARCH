package com.searchFIles.KeywordSearch.Controller;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.searchFIles.KeywordSearch.DAO.SearchDTO;
import com.searchFIles.KeywordSearch.Service.SearchFilesService;





@RestController
@CrossOrigin(origins = "*")
public class SearchController {
	@Autowired
	SearchFilesService sfs;

	
	
	
	@PostMapping(value = "/searchKeyInFiles",consumes="application/json")
	public ResponseEntity<List<List<String>>> searchKeyInFiles(@RequestBody SearchDTO  searchString) throws IOException
	{
		List<String> pathList = new ArrayList<>(2);
		pathList.add("C:/Users/uday.mashetti/Desktop/Trash");
		pathList.add("C:/Users/uday.mashetti/Desktop/Trash - Copy");
		List<List<String>> returnList = new ArrayList<>();
		for(String path : pathList) {
			 File file= new File(path);
			 if(file.isDirectory()) {
	        	 File[] listFiles = file.listFiles();
	        	 System.out.println("SearchController.searchKeyInFiles()");
	        	 returnList.addAll(sfs.getFIleNamesList(listFiles,searchString.getKeyWord(),file.getAbsolutePath()))  ;      	
	        }
		}		
		 return ResponseEntity.ok(returnList);     		
	}

}
